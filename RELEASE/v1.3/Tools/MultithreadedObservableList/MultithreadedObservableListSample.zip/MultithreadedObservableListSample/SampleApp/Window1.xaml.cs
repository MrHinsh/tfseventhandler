﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SampleApp
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private ServerManager ServerManager
        {
            get
            {
                ObjectDataProvider data = Resources["ServerManager"] as ObjectDataProvider;
                return data.Data as ServerManager;
            }
        }

        private void StartStop_Click(object sender, RoutedEventArgs e)
        {
            if (this.ServerManager.IsRunning == false)
            {
                this.ServerManager.Start();
            }
            else
            {
                this.ServerManager.Stop();
            }
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            this.ServerManager.AddTask();
        }
    }
}
