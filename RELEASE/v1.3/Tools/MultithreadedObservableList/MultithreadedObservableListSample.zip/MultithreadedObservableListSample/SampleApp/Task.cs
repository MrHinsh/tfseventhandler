﻿using System;
using System.Collections.Generic;
using System.Text;
using QuantumBitDesigns.Core;
using System.ComponentModel;

namespace SampleApp
{
    public class Task : ICollectionItemNotifyPropertyChanged
    {
        private int _taskId;
        private int _percentComplete;

        public Task(int taskId)
        {
            this._taskId = taskId;
            this._percentComplete = 0;
        }

        public int TaskId
        {
            get { return _taskId; }
            set { _taskId = value; }
        }

        public int PercentComplete
        {
            get { return _percentComplete; }
            set 
            { 
                _percentComplete = value;
                OnCollectionItemPropertyChanged("PercentComplete");
            }
        }

        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler CollectionItemPropertyChanged;
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Raises the PropertyChanged event.
        /// </summary>
        /// <param name="e"></param>
        public void NotifyPropertyChanged(PropertyChangedEventArgs e)
        {
            OnPropertyChanged(e);
        }

        protected void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChangedEventHandler handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        protected void OnCollectionItemPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = this.CollectionItemPropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
