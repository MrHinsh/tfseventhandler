﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using QuantumBitDesigns.Core;
using System.Collections.ObjectModel;
using System.Threading;

namespace SampleApp
{
    public class ServerManager : INotifyPropertyChanged
    {
        private Queue<Task> _queuedTasks;
        private object _queuedTasksLock = new object();
        private int _taskCount;

        private BackgroundWorker _backgroundWorker;
        private ObservableList<Task> _tasks;

        public ServerManager()
        {
            this._queuedTasks = new Queue<Task>();
            this._taskCount = 0;

            this._backgroundWorker = new BackgroundWorker();
            this._backgroundWorker.WorkerSupportsCancellation = true;
            this._backgroundWorker.DoWork += new DoWorkEventHandler(_backgroundWorker_DoWork);
        }

        public ObservableCollection<Task> Tasks
        {
            get
            {
                if (this._tasks == null)
                {
                    return null;
                }

                return this._tasks.ObservableCollection;
            }
        }

        public bool IsRunning
        {
            get
            {
                return this._backgroundWorker.IsBusy;
            }
        }

        public void Start()
        {
            if (this.IsRunning == true)
            {
                throw new InvalidOperationException("Worker is already running");
            }

            //This demonstrates how the ObservableBackgroundList can be created from anywhere on the UI thread
            //It can be created on a worker thread provided the worker thread has a reference to the UI thread's dispatcher
            this._tasks = new ObservableList<Task>(System.Windows.Threading.Dispatcher.CurrentDispatcher);

            //notifies the ListView that the employee binding source has changed
            OnPropertyChanged("Tasks");

            //start the worker that will modify the collection
            //since the worker thread is in the same class and has access to the list, passing in the list is not necessary. 
            //However, for sake of not making the thread dependent upon this class, the list is passed in.
            this._backgroundWorker.RunWorkerAsync(this._tasks);
        }

        public void Stop()
        {
            if (this.IsRunning == true)
            {
                this._backgroundWorker.CancelAsync();
            }
        }

        void _backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            ObservableList<Task> taskRequests = e.Argument as ObservableList<Task>;

            //keep a list of task processors (not to be confused with the observable list of tasks that WPF is observing)
            List<TaskProcessor> processingTasks = new List<TaskProcessor>();

            while (this._backgroundWorker.CancellationPending == false)
            {
                lock (this._queuedTasksLock)
                {
                    //check for pending tasks, if any exist process the task with a TaskProcessor
                    while (this._queuedTasks.Count > 0)
                    {
                        TaskProcessor taskProcessor = new TaskProcessor(taskRequests, this._queuedTasks.Dequeue());
                        processingTasks.Add(taskProcessor);

                        taskProcessor.Start();
                    }
                }

                //remove any complete task processors
                processingTasks.RemoveAll(TaskIsComplete);

                //poll 10 times per second
                Thread.Sleep(100);
            }

            using (TimedLock timedLock = taskRequests.AcquireLock())
            {
                taskRequests.Clear();
            }
        }

        // Search predicate returns true if a task processor is complete
        private static bool TaskIsComplete(TaskProcessor taskProcessor)
        {
            return taskProcessor.IsComplete;
        }

        public void AddTask()
        {
            Task task = new Task(this._taskCount);

            lock (this._queuedTasksLock)
            {
                this._queuedTasks.Enqueue(task);
            }

            this._taskCount++;
        }

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
