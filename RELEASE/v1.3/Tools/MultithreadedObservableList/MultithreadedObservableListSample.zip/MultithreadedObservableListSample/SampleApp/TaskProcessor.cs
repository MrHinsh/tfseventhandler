﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using QuantumBitDesigns.Core;

namespace SampleApp
{
    public class TaskProcessor
    {
        private Task _task;
        private ObservableList<Task> _activeTasks;

        public TaskProcessor(ObservableList<Task> activeTasks, Task task)
        {
            this._activeTasks = activeTasks;
            this._task = task;
        }

        public void Start()
        {
            Thread processTaskThread = new Thread(new ThreadStart(ProcessTask));
            processTaskThread.IsBackground = true;
            processTaskThread.Start();
        }

        private void ProcessTask()
        {
            Random random = new Random((int)DateTime.Now.Ticks);

            //add task to the listview display
            using (TimedLock timedLock = this._activeTasks.AcquireLock())
            {
                this._activeTasks.Add(this._task);
            }

            while (this._task.PercentComplete < 100)
            {
                //simulate some work
                Thread.Sleep(random.Next(100));

                this._task.PercentComplete += random.Next(3);
            }

            //remove task from the listview display
            using (TimedLock timedLock = this._activeTasks.AcquireLock())
            {
                this._activeTasks.Remove(this._task);
            }
        }

        public bool IsComplete
        {
            get
            {
                return this._task.PercentComplete >= 100;
            }
        }

        public Task Task
        {
            get
            {
                return this._task;
            }
        }
    }
}
